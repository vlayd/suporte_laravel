<div class="{{ $height ?? 'min-height-300'}} bg-primary position-absolute w-100"></div>
